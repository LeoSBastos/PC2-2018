package br.com.prog2.heranca2;

public class Veterinario {
    public Veterinario() {
    }

    public void examinar(Animal a){
        System.out.println(a.emiteSom());
    }
}
