package br.com.prog2.trabalho4;




public class Professor {
	String ctps, nome, formacao;

	
	public String toString() {
		return "Nome do Professor: "+this.nome+"\nCTPS: "+this.ctps+"\nFormacao: "+this.formacao;
	}
}
