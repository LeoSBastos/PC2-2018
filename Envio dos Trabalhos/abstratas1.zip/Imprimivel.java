package br.com.prog2.abstratas1;

public interface Imprimivel {

    public abstract String mostrarDados();


}
