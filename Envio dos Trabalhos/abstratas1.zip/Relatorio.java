package br.com.prog2.abstratas1;

public class Relatorio {

    public String gerarRelatorio(Imprimivel obj) {
        return obj.mostrarDados();
    }
}
