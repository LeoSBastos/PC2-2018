package br.com.prog2.heranca1;

public class Pobre extends Pessoa {
	public Pobre() {
		super();
	}
	public String trabalha(){
		return "Estou trabalhando";
	}
}
