package br.com.prog2.heranca1;

public class Gato extends Animal {
	
	public Gato(){
		
	}
	
	public String mia(){
		return "Miau";
	}
}
