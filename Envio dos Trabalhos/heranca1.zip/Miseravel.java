package br.com.prog2.heranca1;

public class Miseravel extends Pessoa {
	public Miseravel() {
		super();
	}
	public String mendiga(){
		return "Me d� dinheiro, favor!";
	}
}
