package br.com.prog2.heranca1;

public class Rica extends Pessoa {
	double dinheiro;
	
	public Rica(){
		super();
	}
	
	public String fazCompras(){
		return "Fazendo Compras";
	}
}
