package br.com.prog2.heranca1;

public class Gerente extends Funcionario {

	public Gerente(String nome) {
		super(nome);
	}

}
