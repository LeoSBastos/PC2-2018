package br.com.prog2.heranca1;

public class Imovel {
	Double preco;
	String endereco;
	
}
