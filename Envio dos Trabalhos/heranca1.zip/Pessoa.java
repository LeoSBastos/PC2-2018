package br.com.prog2.heranca1;

public class Pessoa {
	String nome;
	int idade;
	
	public Pessoa(){
		
	}
}
