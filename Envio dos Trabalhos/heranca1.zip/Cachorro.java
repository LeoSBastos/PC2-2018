package br.com.prog2.heranca1;

public class Cachorro extends Animal{
	
	public Cachorro(){
		super();
	}
	
	public String late(){
		return "Au Au";
	}
}
